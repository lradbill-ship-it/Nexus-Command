# Project Stratadug — NEXUS COMMAND

A Command & Conquer–inspired RTS with a modern drone/cyber-warfare twist: 4 factions, live diplomacy, trade pacts, covert ops, and procedurally generated battlefields.

## What's here

| Path | Status | What it is |
|------|--------|------------|
| `playable/nexus-command-v2.html` | ✅ playable | **Current best build.** Double-click → plays in any browser. 4 factions, diplomacy/trade/covert ops, fog of war. |
| `playable/nexus-command-v1.html` | ✅ playable | Original 1v1 prototype. |
| `wip-v3/` | ⚠ incomplete | Interrupted rewrite. Contains a **working procedural map generator, stereo audio engine, and A\* pathfinding** worth porting. See `wip-v3/V3_STATUS.md`. |
| `CLAUDE.md` | — | **Start here if you're Claude Code.** The full pickup brief. |
| `docs/DESIGN_SPEC.md` | — | Every system, stat table, and the owner's feedback history. |

## For the next developer (human or Claude Code)

1. Open `playable/nexus-command-v2.html` and play a match — that's the gameplay baseline.
2. Read `CLAUDE.md` for the mission and the six hard requirements.
3. Read `docs/DESIGN_SPEC.md` for exact numbers.
4. Build the real version with a proper engine (Phaser 3 / PixiJS + WebGL + real sprite assets). Don't extend the single-file canvas builds.

## Putting this on GitHub

From this folder:

```bash
git init
git add -A
git commit -m "Project Stratadug: NEXUS COMMAND handoff (playable v2 + v3 WIP + specs)"
gh repo create project-stratadug --private --source=. --push   # needs GitHub CLI, logged in
```

No GitHub CLI? Create an empty repo named `project-stratadug` at github.com → "uploading an existing file" → drag this whole folder in.
